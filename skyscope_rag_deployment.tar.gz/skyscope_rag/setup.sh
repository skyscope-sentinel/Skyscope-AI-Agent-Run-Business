#!/bin/bash
# Skyscope RAG System - Quick Setup Guide

echo "🚀 Skyscope RAG System Setup Starting..."

# Check if Ollama is installed
if ! command -v ollama &> /dev/null; then
    echo "❌ Ollama not found. Please install Ollama first:"
    echo "   curl -fsSL https://ollama.ai/install.sh | sh"
    exit 1
fi

# Start Ollama if not running
if ! curl -s http://localhost:11434/api/tags > /dev/null; then
    echo "🔄 Starting Ollama..."
    ollama serve &
    sleep 5
fi

# Pull recommended models
echo "📥 Pulling Ollama models..."
ollama pull codellama
ollama pull nomic-embed-text

# Run Python setup
echo "🐍 Setting up Python environment..."
python3 /home/user/skyscope_rag/scripts/setup.py

echo "✅ Setup complete!"
echo ""
echo "🎯 Next steps:"
echo "1. Index your parquet files:"
echo "   python3 /home/user/skyscope_rag/scripts/main.py index /Users/skyscope.cloud/Documents/github-code"
echo ""
echo "2. Start searching:"
echo "   python3 /home/user/skyscope_rag/scripts/main.py search 'machine learning'"
echo ""
echo "3. Ask questions:"
echo "   python3 /home/user/skyscope_rag/scripts/main.py ask 'How to implement authentication?'"
echo ""
echo "4. Interactive mode:"
echo "   python3 /home/user/skyscope_rag/scripts/main.py interactive"
