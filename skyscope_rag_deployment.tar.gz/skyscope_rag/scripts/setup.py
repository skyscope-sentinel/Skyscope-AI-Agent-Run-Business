#!/usr/bin/env python3
"""
Skyscope RAG System Setup Script
Installs dependencies and configures the system
"""

import subprocess
import sys
import os
from pathlib import Path
import json

def install_packages():
    """Install required Python packages"""
    packages = [
        "sentence-transformers",
        "faiss-cpu",
        "pyarrow",
        "fastparquet", 
        "pandas",
        "numpy",
        "requests",
        "aiohttp",
        "psutil",
        "nltk",
        "tqdm"
    ]

    print("📦 Installing Python packages...")
    for package in packages:
        try:
            subprocess.check_call([sys.executable, "-m", "pip", "install", package])
            print(f"✅ {package}")
        except subprocess.CalledProcessError:
            print(f"❌ Failed to install {package}")

def setup_directories():
    """Create necessary directories"""
    base_dir = Path("/home/user/skyscope_rag")
    dirs = ["indexes", "embeddings", "cache", "logs", "config", "agents", "models", "scripts"]

    print("📁 Creating directories...")
    for dir_name in dirs:
        (base_dir / dir_name).mkdir(parents=True, exist_ok=True)
        print(f"✅ {base_dir / dir_name}")

def create_config():
    """Create default configuration"""
    config = {
        "system": {
            "name": "Skyscope RAG System",
            "version": "1.0.0",
            "base_dir": "/home/user/skyscope_rag",
            "parquet_source": "/Users/skyscope.cloud/Documents/github-code"
        },
        "indexing": {
            "batch_size": 1000,
            "chunk_size": 8192,
            "overlap": 512,
            "min_file_size": 50,
            "max_file_size": 1048576
        },
        "embeddings": {
            "model": "all-MiniLM-L6-v2",
            "dimension": 384,
            "batch_size": 32
        },
        "ollama": {
            "base_url": "http://localhost:11434",
            "default_model": "codellama",
            "timeout": 300
        },
        "search": {
            "max_results": 100,
            "similarity_threshold": 0.7
        }
    }

    config_path = Path("/home/user/skyscope_rag/config/config.json")
    with open(config_path, 'w') as f:
        json.dump(config, f, indent=2)

    print(f"⚙️  Configuration created: {config_path}")

def check_ollama():
    """Check if Ollama is running"""
    try:
        import requests
        response = requests.get("http://localhost:11434/api/tags", timeout=5)
        if response.status_code == 200:
            models = response.json().get('models', [])
            print(f"🤖 Ollama running with {len(models)} models")
            for model in models:
                print(f"  • {model['name']}")
        else:
            print("⚠️  Ollama not responding properly")
    except Exception:
        print("❌ Ollama not running. Please start Ollama first.")

def main():
    print("🚀 Skyscope RAG System Setup")
    print("=" * 40)

    setup_directories()
    install_packages()
    create_config()
    check_ollama()

    print("\n✅ Setup complete!")
    print("🎯 Next steps:")
    print("  1. Start Ollama: ollama serve")
    print("  2. Pull models: ollama pull codellama")
    print("  3. Index files: python main.py index /path/to/parquet/files")
    print("  4. Start searching: python main.py search 'your query'")

if __name__ == "__main__":
    main()
