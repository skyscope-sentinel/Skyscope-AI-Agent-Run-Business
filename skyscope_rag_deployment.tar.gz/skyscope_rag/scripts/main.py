#!/usr/bin/env python3
"""
Skyscope RAG System - Main Executable
Comprehensive RAG system for GitHub codebase search and generation
"""

import sys
import os
import argparse
import json
import logging
from pathlib import Path

# Add the system to Python path
sys.path.insert(0, '/home/user/skyscope_rag')

def setup_logging(debug=False):
    level = logging.DEBUG if debug else logging.INFO
    logging.basicConfig(
        level=level,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
        handlers=[
            logging.StreamHandler(),
            logging.FileHandler('/home/user/skyscope_rag/logs/system.log')
        ]
    )

def main():
    parser = argparse.ArgumentParser(description="Skyscope RAG System")
    parser.add_argument('--debug', action='store_true', help='Enable debug logging')
    subparsers = parser.add_subparsers(dest='command', help='Commands')

    # Index command
    index_parser = subparsers.add_parser('index', help='Index Parquet files')
    index_parser.add_argument('directory', help='Directory with Parquet files')
    index_parser.add_argument('--max-files', type=int, help='Max files to process')
    index_parser.add_argument('--batch-size', type=int, default=1000, help='Batch size')

    # Search command
    search_parser = subparsers.add_parser('search', help='Search codebase')
    search_parser.add_argument('query', help='Search query')
    search_parser.add_argument('--type', choices=['keyword', 'semantic', 'hybrid'], 
                              default='hybrid')
    search_parser.add_argument('--language', help='Programming language filter')
    search_parser.add_argument('--max-results', type=int, default=10)
    search_parser.add_argument('--output', help='Output file for results')

    # Ask command
    ask_parser = subparsers.add_parser('ask', help='Ask question with RAG')
    ask_parser.add_argument('question', help='Question to ask')
    ask_parser.add_argument('--language', help='Language filter')
    ask_parser.add_argument('--execute', action='store_true', help='Execute code')
    ask_parser.add_argument('--model', help='Ollama model to use')

    # Interactive mode
    subparsers.add_parser('interactive', help='Start interactive mode')

    # Stats command
    subparsers.add_parser('stats', help='Show statistics')

    args = parser.parse_args()
    setup_logging(args.debug)

    if not args.command:
        parser.print_help()
        return

    # Import here to avoid issues if dependencies are missing
    try:
        from rag_system import SkyscopeRAGSystem
        system = SkyscopeRAGSystem()
    except ImportError as e:
        print(f"Error: Missing dependencies. Run setup.py first. {e}")
        return 1

    if args.command == 'index':
        print(f"🔄 Indexing files from: {args.directory}")
        result = system.index_parquet_files(args.directory, args.max_files)
        print(f"✅ Indexed {result.get('total_processed', 0)} files")

    elif args.command == 'search':
        print(f"🔍 Searching for: {args.query}")
        results = system.search(args.query, args.type, args.language, args.max_results)

        print(f"📊 Found {len(results)} results:")
        for i, result in enumerate(results[:5]):
            print(f"  {i+1}. {result['repo_name']}/{result['file_path']} ({result['language']})")

        if args.output:
            system.export_results(results, args.output)
            print(f"💾 Results saved to {args.output}")

    elif args.command == 'ask':
        if args.model:
            system.switch_ollama_model(args.model)

        print(f"❓ Question: {args.question}")
        response = system.ask(args.question, args.language, args.execute)

        print("🤖 Response:")
        print(response.get('rag_response', 'No response'))

        if 'relevant_files' in response:
            print("📁 Relevant files:")
            for file_info in response['relevant_files']:
                print(f"  • {file_info['repo']}/{file_info['path']}")

    elif args.command == 'interactive':
        interactive_mode(system)

    elif args.command == 'stats':
        stats = system.get_stats()
        print("📊 System Statistics:")
        for key, value in stats.items():
            print(f"  {key}: {value}")

def interactive_mode(system):
    """Interactive REPL mode"""
    print("🎮 Skyscope RAG Interactive Mode")
    print("Commands: search, ask, stats, model, quit")
    print("=" * 50)

    while True:
        try:
            command = input("skyscope> ").strip()
            if not command:
                continue

            if command == 'quit' or command == 'exit':
                break
            elif command == 'stats':
                stats = system.get_stats()
                for key, value in stats.items():
                    print(f"  {key}: {value}")
            elif command.startswith('search '):
                query = command[7:]
                results = system.search(query)
                print(f"Found {len(results)} results:")
                for i, r in enumerate(results[:3]):
                    print(f"  {i+1}. {r['repo_name']}/{r['file_path']}")
            elif command.startswith('ask '):
                question = command[4:]
                response = system.ask(question)
                print("Response:", response.get('rag_response', 'No response'))
            elif command.startswith('model '):
                model_name = command[6:]
                if system.switch_ollama_model(model_name):
                    print(f"Switched to model: {model_name}")
                else:
                    print(f"Model not available: {model_name}")
            else:
                print("Unknown command. Try: search, ask, stats, model, quit")

        except KeyboardInterrupt:
            print("\nExiting...")
            break
        except Exception as e:
            print(f"Error: {e}")

if __name__ == "__main__":
    sys.exit(main())
